¿Cómo empezar con React?

¿Es necesario utilizar Redux ahora tenemos los hooks y el Context Api?

¿Cómo es utilizar Redux con hooks y con el estilo anterior (cual es el estilo anterior?)

¿Cómo incorporar el nuevo estilo (nueva API) de Redux

¿Es mejor o peor esta API?

node
npx create-react-app my-app